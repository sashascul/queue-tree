#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define LEN 50

typedef struct {

  char title[LEN];
  char author[LEN];

} Book;

typedef struct tree {

  Book param;
  struct tree * right;
  struct tree * left;

} Node;


void InitializeTree (Node * pt, Book key);
void AddItem (Node * ptn, Book key);

int main (void) {
	
  Node tree;
  Book key;

  puts ("Input title of book:");
  gets (key.title);
  puts ("Input author this book:");
  gets (key.author);

  InitializeTree (&tree, key);

  puts ("Input title of book:");

  while (gets (key.title) != NULL && key.title[0] != '\0') {

    puts ("Input author this book:");
    gets (key.author);

    AddItem (&tree, key);

    puts ("Input title of book:");

  }

  Node * ptr;
  ptr = (Node * ) malloc (sizeof (Node));
  ptr = &tree;

  puts ("Left branch:");

  while (ptr != 0) {

    puts ((ptr->param).title);
    ptr = ptr->left;

  }

  putchar ('\n');
  putchar ('\n');
  puts ("Right branch:");

  while (ptr != 0) {

    puts ((ptr->param).title);
    ptr = ptr->right;

  }
  
  
	
}

void InitializeTree (Node * pt, Book key) {

  pt->right = NULL;
  pt->left = NULL;
  pt->param = key;


}

void AddItem (Node * ptn, Book key) {

  Node * mem, * start = ptn;
  mem = (Node * ) malloc (sizeof (Node));

  mem->param = key;

  while (start != NULL) {

    if (strcmp (key.title, (start->param).title) > 0) {

      start = start->left;
      continue;

    }

    if (strcmp (key.title, (start->param).title) < 0) {

      start = start->right;
      continue;

    }

    else
      exit (1);

  }

  mem->left = NULL;
  mem->right = NULL;
  start = mem;



}
